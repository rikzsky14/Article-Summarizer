"""Required constants for the Reddit API."""

# The following constants are used by the bot.
REDDIT_USERNAME = ""
REDDIT_PASSWORD = ""

APP_ID = ""
APP_SECRET = ""
USER_AGENT = ""

SUBREDDITS = ["mexico"]

IMGUR_CLIENT_ID = ""